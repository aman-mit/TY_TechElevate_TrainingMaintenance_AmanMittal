import { Component, OnInit } from '@angular/core';
import { BatchService } from '../batch.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-batch-details',
  templateUrl: './batch-details.component.html',
  styleUrls: ['./batch-details.component.css']
})
export class BatchDetailsComponent implements OnInit {

  constructor(private service:BatchService) {
   }
   batchdetails(data){
     console.log(data)
     this.service.postdetails(data).subscribe(data =>{
       console.log(data)
     },err=>{
       console.log(err)
     },()=>{
       console.log("Post Successfully")
     })
   }

  ngOnInit() {
	 	$(".input").focus(function() {
	 		$(this).parent().addClass("focus");
	 	})

  }

}
